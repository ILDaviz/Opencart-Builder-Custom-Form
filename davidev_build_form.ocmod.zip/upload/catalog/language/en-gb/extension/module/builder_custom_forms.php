<?php
$_['success']           = 'Success email sending';
$_['error_missing_email_to']        = 'Error: Please contact admin of site';
$_['text_email_head'] = 'Email from custom form';
